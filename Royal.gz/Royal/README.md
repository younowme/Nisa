# FuckBot V1
Mastah Of Kicker :v

Catatan : 
- Ini Bot paling kampret yang pernah saya buat :v

# DANGER DANGER
Jika akun BOT diundang oleh orang lain, maka si bot akan langsung menerima undangan grup tersebut dan Bot akan langsung meng-KICK semua member yang ada di grup tersebut :D KAMPRET BUKAN?

### Cara ubah login versi authtoken ( Login Otomatis )
Ubah script dibawah ini
```bash
cl = LINETCR.LINE()
cl.login(qr=True)
cl.loginResult()
```
menjadi
```bash
cl = LINETCR.LINE()
cl.login(token="authtoken-ente")
cl.loginResult()
```

### Cara mendapatkan authtoken
Saat pertama login, pada terminal / termux kalian, kalian akan diberi authtoken kalian, contohnya
```bash
authToken -> EmGxXwhjizYIReLFxxxx.eFtfXEQQ9zeBAclHFogALq.3sv5woAxxxxHYXBJFxxxxxxxPToPfzUNv2VYvSXXXX=
```

Bot akan langsung kick jika ada :
- Member Join Grup
- Member Keluar Grup
- Ada Member Kick Member Lainnya

Keyword Bot :
- Gk ada :D

### Created By Farzain - zFz
